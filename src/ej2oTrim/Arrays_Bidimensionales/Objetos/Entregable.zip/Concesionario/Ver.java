package ej2oTrim.Arrays_Bidimensionales.Objetos.Concesionario;

public class Ver {
    public static void verArray(Coche[] array) {
        for (Coche coche : array) {
            System.out.println(coche.toString());
        }
    }
}
