package ej2oTrim.Arrays_Bidimensionales.Objetos.Entregable;

public class Alumno {
    String nombre;
    int nota;

    public Alumno(String nombre, int nota) {
        this.nombre = nombre;
        this.nota = nota;
    }

}
